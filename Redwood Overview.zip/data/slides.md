# Redwood Springs Capital partners

### Founder aligned funding and building sustainable cash flows and long term value 

---

## Who we are

- Founders and operators who created the funding company we needed.
- Extensive experience founding, launching, operating and exiting 
- Tired of cookie cutter investment mills who are running their own money from exits
- Bucking the status quo 

---

## Core principles 

- No fees. No 2/20 here!
- Founders truly in control
- Our funds sign NDAs with founders
- Focus on long term , steady liquidity/cash flow. No spiky exits.
- Running other peoples money , stewarding it and growing it. 

## LP Terms
- 70/30 LP favor 
- Fund general partners make 145k per year. All other comp is equity. Grow the whole pie!

## Fund minimum size / profile
- 25 million minimum
- 1 million fixed overhead fee for 20 million or more
- 100k overhead for each additional 10 millon (typically deploying into hardware or boil the ocean startups in bundled chunks)

---
## Funds
- Avenue G Ventures
- Boring & Beautiful Holdings
- TheCampus Trading 
- Blended

---

## Avenue G
- Investing in Austin metro area geo
- Inverting the typical demographic model and seekidiverse founder profies
- Looking under the poverty line, seeking rising stars, gumption, grit
- Want hard problems with large addressable markets
- 3 to 5 person team size ideal (couple people in a garage ish)
- 1 to 15 million funding target


---
## Risk profile
- Mixed 
- Allow for exposure to different levels of risk/reward 
